(function (root, factory) {
  if (typeof module === "object" && module.exports) {
    module.exports = factory();
    return;
  }

  root.VideoSpeedShared = factory();
})(typeof globalThis !== "undefined" ? globalThis : this, () => {
  const NORMAL_SPEED = 1;
  const DOUBLE_SPEED = 2;

  const OVERRIDE_AUTO = "auto";
  const OVERRIDE_NORMAL = "1x";
  const OVERRIDE_DOUBLE = "2x";

  const MESSAGE_TYPES = {
    ACTIVE_TAB_REQUEST: "ACTIVE_TAB_REQUEST",
    GET_STATUS: "GET_STATUS",
    SET_OVERRIDE: "SET_OVERRIDE"
  };

  const MUSIC_HOSTS = new Set([
    "music.youtube.com",
    "open.spotify.com",
    "soundcloud.com",
    "www.soundcloud.com",
    "bandcamp.com",
    "www.bandcamp.com",
    "music.apple.com",
    "music.amazon.com",
    "play.qobuz.com",
    "listen.tidal.com",
    "tidal.com",
    "www.deezer.com",
    "www.pandora.com",
    "www.iheart.com"
  ]);

  const MUSIC_GENRE_PATTERN =
    /\b(music|song|songs|album|albums|single|ep|soundtrack|playlist|concert film)\b/i;

  const STRONG_TITLE_PATTERNS = [
    /\bofficial music video\b/i,
    /\bmusic video\b/i,
    /\bofficial audio\b/i,
    /\blyric video\b/i,
    /\blyrics\b/i,
    /\bvisualizer\b/i,
    /\baudio only\b/i,
    /\bfull album\b/i,
    /\balbum stream\b/i
  ];

  function normalizeOverride(value) {
    if (value === OVERRIDE_DOUBLE || value === DOUBLE_SPEED || value === "toggle") {
      return value === "toggle" ? value : OVERRIDE_DOUBLE;
    }

    if (value === OVERRIDE_NORMAL || value === NORMAL_SPEED) {
      return OVERRIDE_NORMAL;
    }

    return OVERRIDE_AUTO;
  }

  function isMusicHost(hostname) {
    return MUSIC_HOSTS.has((hostname || "").toLowerCase());
  }

  function containsMusicGenre(values) {
    for (const value of values || []) {
      if (MUSIC_GENRE_PATTERN.test(String(value || ""))) {
        return true;
      }
    }

    return false;
  }

  function scoreTitle(title) {
    let score = 0;

    for (const pattern of STRONG_TITLE_PATTERNS) {
      if (pattern.test(title || "")) {
        score += 1;
      }
    }

    return score;
  }

  function evaluateMusicContext(snapshot) {
    const hostname = String(snapshot?.hostname || "").toLowerCase();
    const title = String(snapshot?.title || "");
    const genres = Array.isArray(snapshot?.genres) ? snapshot.genres : [];
    const tags = Array.isArray(snapshot?.tags) ? snapshot.tags : [];
    const youtubeCategory = String(snapshot?.youtubeCategory || "");
    const musicVideoType = String(snapshot?.musicVideoType || "");

    if (isMusicHost(hostname)) {
      return {
        isMusicContext: true,
        reason: `Known music site: ${hostname}.`
      };
    }

    if (/^music$/i.test(youtubeCategory)) {
      return {
        isMusicContext: true,
        reason: "YouTube marked this page as Music."
      };
    }

    if (/^music_video_type_/i.test(musicVideoType)) {
      return {
        isMusicContext: true,
        reason: "YouTube metadata identifies this as a music video."
      };
    }

    if (containsMusicGenre(genres)) {
      return {
        isMusicContext: true,
        reason: "Page metadata includes a music genre."
      };
    }

    if (containsMusicGenre(tags)) {
      return {
        isMusicContext: true,
        reason: "Structured data tags this page as music-related."
      };
    }

    const titleScore = scoreTitle(title);
    if (titleScore >= 2) {
      return {
        isMusicContext: true,
        reason: "Title strongly looks like a music video."
      };
    }

    return {
      isMusicContext: false,
      reason: "No strong music-video signals were detected."
    };
  }

  function getEffectiveSpeed(override, isMusicContext) {
    const normalized = normalizeOverride(override);

    if (normalized === OVERRIDE_DOUBLE) {
      return DOUBLE_SPEED;
    }

    if (normalized === OVERRIDE_NORMAL) {
      return NORMAL_SPEED;
    }

    return isMusicContext ? null : DOUBLE_SPEED;
  }

  function getNextToggleOverride(currentSpeed) {
    return currentSpeed === DOUBLE_SPEED ? OVERRIDE_NORMAL : OVERRIDE_DOUBLE;
  }

  return {
    DOUBLE_SPEED,
    MESSAGE_TYPES,
    NORMAL_SPEED,
    OVERRIDE_AUTO,
    OVERRIDE_DOUBLE,
    OVERRIDE_NORMAL,
    evaluateMusicContext,
    getEffectiveSpeed,
    getNextToggleOverride,
    normalizeOverride
  };
});
