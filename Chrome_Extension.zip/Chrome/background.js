importScripts("shared.js");

const {
  MESSAGE_TYPES,
  OVERRIDE_AUTO,
  OVERRIDE_DOUBLE,
  OVERRIDE_NORMAL
} = globalThis.VideoSpeedShared;

async function getActiveTabId() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab?.id ?? null;
}

async function sendMessageToActiveTab(message) {
  const tabId = await getActiveTabId();
  if (!tabId) {
    return { ok: false, reason: "no-tab" };
  }

  try {
    const response = await chrome.tabs.sendMessage(tabId, message);
    return response ?? { ok: false, reason: "no-response" };
  } catch {
    return { ok: false, reason: "not-allowed" };
  }
}

chrome.commands.onCommand.addListener((command) => {
  if (command === "toggle-speed") {
    void sendMessageToActiveTab({
      type: MESSAGE_TYPES.SET_OVERRIDE,
      override: "toggle"
    });
    return;
  }

  if (command === "set-normal-speed") {
    void sendMessageToActiveTab({
      type: MESSAGE_TYPES.SET_OVERRIDE,
      override: OVERRIDE_NORMAL
    });
    return;
  }

  if (command === "set-double-speed") {
    void sendMessageToActiveTab({
      type: MESSAGE_TYPES.SET_OVERRIDE,
      override: OVERRIDE_DOUBLE
    });
  }
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== MESSAGE_TYPES.ACTIVE_TAB_REQUEST) {
    return;
  }

  (async () => {
    if (message.action === MESSAGE_TYPES.GET_STATUS) {
      const response = await sendMessageToActiveTab({ type: MESSAGE_TYPES.GET_STATUS });
      sendResponse(response);
      return;
    }

    if (message.action === MESSAGE_TYPES.SET_OVERRIDE) {
      const override = message.override ?? OVERRIDE_AUTO;
      const response = await sendMessageToActiveTab({
        type: MESSAGE_TYPES.SET_OVERRIDE,
        override
      });
      sendResponse(response);
      return;
    }

    sendResponse({ ok: false, reason: "unknown-action" });
  })();

  return true;
});
