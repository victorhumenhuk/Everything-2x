const { MESSAGE_TYPES, OVERRIDE_AUTO, OVERRIDE_DOUBLE, OVERRIDE_NORMAL } =
  globalThis.VideoSpeedShared;

const statusEl = document.getElementById("status");
const detailEl = document.getElementById("detail");
const badgeEl = document.getElementById("speedBadge");
const autoBtn = document.getElementById("setAuto");
const set2xBtn = document.getElementById("set2x");
const set1xBtn = document.getElementById("set1x");
const buttons = [autoBtn, set2xBtn, set1xBtn];

function setBusy(isBusy) {
  for (const button of buttons) {
    button.disabled = isBusy;
  }
}

function setSelectedOverride(override) {
  for (const button of buttons) {
    const matches = button.dataset.override === override;
    button.setAttribute("aria-pressed", String(matches));
    button.classList.toggle("is-selected", matches);
  }
}

function setBadge(state, label) {
  badgeEl.dataset.state = state;
  statusEl.textContent = label;
}

function describeStatus(response) {
  const videos =
    response.videoCount === 1
      ? "1 video on page"
      : `${response.videoCount} videos on page`;

  if (response.override === OVERRIDE_AUTO) {
    if (response.autoDetectedMusic) {
      return {
        state: "music",
        label: "Music detected \u2014 playing at 1x",
        detail: `${response.reason} ${videos}.`
      };
    }
    return {
      state: "fast",
      label: "Auto 2x active",
      detail: `${response.reason} ${videos}.`
    };
  }

  if (response.override === OVERRIDE_DOUBLE) {
    return {
      state: "fast",
      label: "Forced 2x on this tab",
      detail: `${videos}.`
    };
  }

  return {
    state: "normal",
    label: "Forced 1x on this tab",
    detail: `${videos}.`
  };
}

async function requestActiveTab(action, override) {
  return chrome.runtime.sendMessage({
    type: MESSAGE_TYPES.ACTIVE_TAB_REQUEST,
    action,
    override
  });
}

async function refreshStatus() {
  setBusy(true);

  try {
    const response = await requestActiveTab(MESSAGE_TYPES.GET_STATUS);

    if (!response?.ok) {
      setSelectedOverride(OVERRIDE_AUTO);
      setBadge("error", "Page not controllable");
      detailEl.textContent = "Chrome blocks extensions on this page.";
      return;
    }

    setSelectedOverride(response.override);
    const { state, label, detail } = describeStatus(response);
    setBadge(state, label);
    detailEl.textContent = detail;
  } catch {
    setSelectedOverride(OVERRIDE_AUTO);
    setBadge("error", "Page not controllable");
    detailEl.textContent = "Chrome blocks extensions on this page.";
  } finally {
    setBusy(false);
  }
}

async function applyOverride(override) {
  setBusy(true);
  setBadge("normal", "Applying...");
  detailEl.textContent = "";

  try {
    const response = await requestActiveTab(MESSAGE_TYPES.SET_OVERRIDE, override);

    if (!response?.ok) {
      setBadge("error", "Unable to update");
      detailEl.textContent = "Chrome blocks extensions on this page.";
      return;
    }

    setSelectedOverride(response.override);
    const { state, label, detail } = describeStatus(response);
    setBadge(state, label);
    detailEl.textContent = detail;
  } catch {
    setBadge("error", "Unable to update");
    detailEl.textContent = "Chrome blocks extensions on this page.";
  } finally {
    setBusy(false);
  }
}

autoBtn.addEventListener("click", () => applyOverride(OVERRIDE_AUTO));
set2xBtn.addEventListener("click", () => applyOverride(OVERRIDE_DOUBLE));
set1xBtn.addEventListener("click", () => applyOverride(OVERRIDE_NORMAL));

void refreshStatus();
