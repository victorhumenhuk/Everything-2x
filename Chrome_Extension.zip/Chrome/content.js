const {
  DOUBLE_SPEED,
  MESSAGE_TYPES,
  NORMAL_SPEED,
  OVERRIDE_AUTO,
  evaluateMusicContext,
  getEffectiveSpeed,
  getNextToggleOverride,
  normalizeOverride
} = globalThis.VideoSpeedShared;

const trackedVideos = new WeakMap();

const state = {
  override: OVERRIDE_AUTO,
  autoDetectedMusic: false,
  effectiveSpeed: null,
  reason: "Checking page signals...",
  lastUrl: location.href,
  reevaluateTimer: null
};

function isVideoElement(node) {
  return node instanceof HTMLVideoElement;
}

function collectVideos(root, collected = [], seen = new Set(), depth = 0) {
  if (!root || typeof root.querySelectorAll !== "function" || depth > 20) {
    return collected;
  }

  if (isVideoElement(root) && !seen.has(root)) {
    seen.add(root);
    collected.push(root);
  }

  for (const video of root.querySelectorAll("video")) {
    if (!seen.has(video)) {
      seen.add(video);
      collected.push(video);
    }
  }

  for (const element of root.querySelectorAll("*")) {
    if (element.shadowRoot) {
      collectVideos(element.shadowRoot, collected, seen, depth + 1);
    }
  }

  return collected;
}

let syncing = false;

function setVideoSpeed(video, speed) {
  try { video.playbackRate = speed; } catch { /* locked player */ }
  try { video.defaultPlaybackRate = speed; } catch { /* locked player */ }
}

function syncVideoToPolicy(video) {
  if (syncing) {
    return;
  }

  const tracked = trackedVideos.get(video);
  if (!tracked) {
    return;
  }

  syncing = true;

  try {
    if (state.effectiveSpeed == null) {
      if (tracked.lastAppliedSpeed != null) {
        setVideoSpeed(video, NORMAL_SPEED);
        tracked.lastAppliedSpeed = null;
      }
      return;
    }

    if (
      video.playbackRate !== state.effectiveSpeed ||
      video.defaultPlaybackRate !== state.effectiveSpeed
    ) {
      setVideoSpeed(video, state.effectiveSpeed);
    }

    tracked.lastAppliedSpeed = state.effectiveSpeed;
  } finally {
    syncing = false;
  }
}

function trackVideo(video) {
  if (trackedVideos.has(video)) {
    return;
  }

  const sync = () => syncVideoToPolicy(video);

  video.addEventListener("loadedmetadata", sync, { passive: true });
  video.addEventListener("play", sync, { passive: true });
  video.addEventListener("ratechange", sync, { passive: true });

  trackedVideos.set(video, {
    lastAppliedSpeed: null,
    sync
  });

  syncVideoToPolicy(video);
}

function syncAllVideos() {
  for (const video of collectVideos(document)) {
    trackVideo(video);
    syncVideoToPolicy(video);
  }
}

function safeJsonParse(text) {
  try { return JSON.parse(text); } catch { return null; }
}

function flattenStructuredValues(value, values) {
  if (!value) {
    return;
  }

  if (typeof value === "string") {
    values.push(value);
    return;
  }

  if (Array.isArray(value)) {
    for (const item of value) {
      flattenStructuredValues(item, values);
    }
    return;
  }

  if (typeof value === "object") {
    for (const key of ["genre", "keywords", "category", "musicBy", "byArtist"]) {
      flattenStructuredValues(value[key], values);
    }
  }
}

function collectMetadataContent(selectors) {
  const values = [];

  for (const selector of selectors) {
    for (const node of document.querySelectorAll(selector)) {
      const content = node.getAttribute("content") || node.textContent || "";
      if (content.trim()) {
        values.push(content.trim());
      }
    }
  }

  return values;
}

function getYoutubeMetadata() {
  const response =
    window.ytInitialPlayerResponse ||
    window.ytplayer?.config?.args?.raw_player_response ||
    null;

  let parsed = response;
  if (typeof parsed === "string") {
    parsed = safeJsonParse(parsed);
  }

  const microformat = parsed?.microformat?.playerMicroformatRenderer;
  const videoDetails = parsed?.videoDetails;

  return {
    youtubeCategory: microformat?.category || "",
    musicVideoType: videoDetails?.musicVideoType || ""
  };
}

function buildPageSnapshot() {
  const genres = collectMetadataContent([
    'meta[itemprop="genre"]',
    'meta[name="genre"]',
    'meta[property="video:tag"]',
    'meta[property="music:musician"]',
    'meta[property="music:song"]',
    'meta[property="music:album"]'
  ]);

  const tags = [];
  for (const node of document.querySelectorAll('script[type="application/ld+json"]')) {
    const parsed = safeJsonParse(node.textContent || "");
    flattenStructuredValues(parsed, tags);
  }

  const youtubeMetadata = getYoutubeMetadata();

  return {
    hostname: location.hostname,
    title: document.title,
    genres,
    tags,
    youtubeCategory: youtubeMetadata.youtubeCategory,
    musicVideoType: youtubeMetadata.musicVideoType
  };
}

function applyResolvedPolicy() {
  const snapshot = buildPageSnapshot();
  const evaluation = evaluateMusicContext(snapshot);

  state.autoDetectedMusic = evaluation.isMusicContext;
  state.reason = evaluation.reason;
  state.lastUrl = location.href;

  const nextSpeed = getEffectiveSpeed(state.override, state.autoDetectedMusic);
  const speedChanged = nextSpeed !== state.effectiveSpeed;
  state.effectiveSpeed = nextSpeed;

  if (speedChanged || collectVideos(document).length > 0) {
    syncAllVideos();
  }
}

function scheduleReevaluation(delay = 150) {
  clearTimeout(state.reevaluateTimer);
  state.reevaluateTimer = setTimeout(() => {
    applyResolvedPolicy();
  }, delay);
}

function shouldReevaluateForMutation(mutation) {
  if (location.href !== state.lastUrl) {
    return true;
  }

  const targetName = mutation.target?.nodeName;
  if (targetName === "TITLE" || targetName === "HEAD") {
    return true;
  }

  for (const node of mutation.addedNodes) {
    if (!(node instanceof Element)) {
      continue;
    }

    const name = node.nodeName;
    if (
      name === "META" ||
      name === "TITLE" ||
      name === "SCRIPT" ||
      node.matches("ytd-watch-flexy, ytd-watch-metadata")
    ) {
      return true;
    }
  }

  return false;
}

function installObservers() {
  const observer = new MutationObserver((mutations) => {
    let shouldReevaluate = false;

    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (!(node instanceof Element)) {
          continue;
        }

        if (isVideoElement(node)) {
          trackVideo(node);
        }

        for (const video of collectVideos(node)) {
          trackVideo(video);
        }
      }

      if (!shouldReevaluate && shouldReevaluateForMutation(mutation)) {
        shouldReevaluate = true;
      }
    }

    if (shouldReevaluate) {
      scheduleReevaluation();
    }
  });

  const target = document.documentElement || document;
  observer.observe(target, { childList: true, subtree: true });
}

function installNavigationHooks() {
  const { pushState, replaceState } = history;

  history.pushState = function (...args) {
    const result = pushState.apply(this, args);
    scheduleReevaluation();
    return result;
  };

  history.replaceState = function (...args) {
    const result = replaceState.apply(this, args);
    scheduleReevaluation();
    return result;
  };

  window.addEventListener("popstate", () => scheduleReevaluation(), { passive: true });
  window.addEventListener("hashchange", () => scheduleReevaluation(), { passive: true });
  document.addEventListener("DOMContentLoaded", () => scheduleReevaluation(0), {
    passive: true
  });
  window.addEventListener("load", () => scheduleReevaluation(0), { passive: true });
}

function getStatus() {
  return {
    ok: true,
    override: state.override,
    autoDetectedMusic: state.autoDetectedMusic,
    effectiveSpeed: state.effectiveSpeed,
    reason: state.reason,
    videoCount: collectVideos(document).length
  };
}

function setOverride(requestedOverride) {
  const normalized = normalizeOverride(requestedOverride);

  if (normalized === "toggle") {
    state.override = getNextToggleOverride(state.effectiveSpeed);
  } else {
    state.override = normalized;
  }

  applyResolvedPolicy();
  return getStatus();
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message?.type) {
    return;
  }

  if (message.type === MESSAGE_TYPES.GET_STATUS) {
    sendResponse(getStatus());
    return;
  }

  if (message.type === MESSAGE_TYPES.SET_OVERRIDE) {
    sendResponse(setOverride(message.override));
  }
});

installNavigationHooks();
installObservers();
applyResolvedPolicy();
